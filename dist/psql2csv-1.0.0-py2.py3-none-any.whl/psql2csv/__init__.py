from .download import download_table
from .download import download_schema
from .download import download_all
from .database import DataBase

__version__ = "1.0.0"
